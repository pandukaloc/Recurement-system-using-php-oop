<?php

namespace Mpdf\Tag;

class Header extends BlockTag
{


}
